// MyGLWidget.cpp
#include "MyGLWidget.h"
#include <iostream>
#include <stdio.h>

#define printOpenGLError() printOglError(__FILE__, __LINE__)
#define CHECK() printOglError(__FILE__, __LINE__,__FUNCTION__)
#define DEBUG() std::cout << __FILE__ << " " << __LINE__ << " " << __FUNCTION__ << std::endl;

int MyGLWidget::printOglError(const char file[], int line, const char func[]) 
{
    GLenum glErr;
    int    retCode = 0;

    glErr = glGetError();
    const char * error = 0;
    switch (glErr)
    {
        case 0x0500:
            error = "GL_INVALID_ENUM";
            break;
        case 0x501:
            error = "GL_INVALID_VALUE";
            break;
        case 0x502: 
            error = "GL_INVALID_OPERATION";
            break;
        case 0x503:
            error = "GL_STACK_OVERFLOW";
            break;
        case 0x504:
            error = "GL_STACK_UNDERFLOW";
            break;
        case 0x505:
            error = "GL_OUT_OF_MEMORY";
            break;
        default:
            error = "unknown error!";
    }
    if (glErr != GL_NO_ERROR)
    {
        printf("glError in file %s @ line %d: %s function: %s\n",
                             file, line, error, func);
        retCode = 1;
    }
    return retCode;
}

MyGLWidget::~MyGLWidget() {
}

void MyGLWidget::initializeGL ()
{
  // Cal inicialitzar l'ús de les funcions d'OpenGL
  initializeOpenGLFunctions();  

  angleX = 0.5;
  angleY = -0.5;
  focusC = false;
  angleA = 0.0;
  alçadaA = 0;
  camera2 = false;
  emit cam2(camera2);
  emit Avio2(alçadaA);

  connect(&timer, SIGNAL(timeout()), this, SLOT(moviment()));
  glClearColor(0.5, 0.7, 1.0, 1.0); // defineix color de fons (d'esborrat)
  glEnable(GL_DEPTH_TEST);
  carregaShaders();
  iniEscena ();
  iniCamera ();

}

void MyGLWidget::iniEscena ()
{
  creaBuffersPatricio();
  creaBuffersAvio();
  creaBuffersHangar();
  creaBuffersTerra();

  // Paràmetres de l'escena - arbitraris
  centreEsc = glm::vec3 (15, 1.25, 12);
  radiEsc = sqrt(15*15+1.25*1.25+12*12);
}

void MyGLWidget::iniMaterialTerra()
{
  // Donem valors al material del terra
    amb = glm::vec3(0.2,0.1,0.2);
    diff = glm::vec3(0,1,1);
    spec = glm::vec3(1,1,1);
    shin = 100;
  
}

void MyGLWidget::enviaPosFocus()
{
  ExamGLWidget::enviaPosFocus();
  glm::vec3 posFoc2 = glm::vec3(0,0,0);
   if (!focusC) {
     float cola = (capsaAvioMax.z-capsaAvioMin.z)/2*escalaAvio*1.5;
     float radiAux = sqrt(10*10 + cola*cola);
     posFoc2 = glm::vec3(View * glm::vec4(glm::vec3(15+(radiAux*cos(-angleA-0.25)), alçadaA+0.75, 12+(radiAux*sin(-angleA-0.25))),1));
   }
   glUniform3fv (posfocusLoc2, 1, &posFoc2[0]);

}

void MyGLWidget::iniCamera ()
{
  ExamGLWidget::iniCamera();
}

void MyGLWidget::paintGL ()
{
// En cas de voler canviar els paràmetres del viewport, descomenteu la crida següent i
// useu els paràmetres que considereu (els que hi ha són els de per defecte)
//  glViewport (0, 0, ample, alt);
  
  // Esborrem el frame-buffer i el depth-buffer
  glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  // inicialitzem llum
  enviaPosFocus();

  // Pintem el terra
  glBindVertexArray (VAO_Terra);
  modelTransformTerra ();
  glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);

  // Pintem el Patricio
  glBindVertexArray (VAO_Patr);
  modelTransformPatricio ();
  glDrawArrays(GL_TRIANGLES, 0, patr.faces().size()*3);

  // Pintem l'Avio
  glBindVertexArray (VAO_Avio);
  modelTransformAvio ();
  glDrawArrays(GL_TRIANGLES, 0, avio.faces().size()*3);

  // Pintem l'Hangar
  glBindVertexArray (VAO_Hang);
  modelTransformHangar ();
  glDrawArrays(GL_TRIANGLES, 0, hang.faces().size()*3);

  glBindVertexArray(0);
}

void MyGLWidget::modelTransformPatricio ()
{
  glm::mat4 TG(1.f);
  
  TG = glm::translate(TG, glm::vec3 (15, 0, 12));
  TG = glm::rotate(TG, -float(M_PI/2), glm::vec3 (0, 1, 0));
  TG = glm::scale(TG, glm::vec3 (escalaPat*2, escalaPat*2, escalaPat*2));
  TG = glm::translate(TG, -centreBasePat);
  
  glUniformMatrix4fv (transLoc, 1, GL_FALSE, &TG[0][0]);
}

void MyGLWidget::modelTransformAvio ()
{
  TGAvio = glm::mat4(1.f);
   
  TGAvio = glm::translate(TGAvio, glm::vec3 (15, alçadaA, 12));
  TGAvio = glm::rotate(TGAvio, -angleA, glm::vec3 (0, 1, 0));
  TGAvio = glm::translate(TGAvio, glm::vec3 (10, 0, 0));
  TGAvio = glm::scale(TGAvio, glm::vec3 (escalaAvio*1.5, escalaAvio*1.5, escalaAvio*1.5));
  TGAvio = glm::translate(TGAvio, -centreBaseAvio);
  
  glUniformMatrix4fv (transLoc, 1, GL_FALSE, &TGAvio[0][0]);
}

void MyGLWidget::viewTransform ()
{
  if (!camera2){
    View = glm::translate(glm::mat4(1.f), glm::vec3(0, 0, -2*radiEsc));
    View = glm::rotate(View, angleX, glm::vec3(1, 0, 0));
    View = glm::rotate(View, angleY, glm::vec3(0, 1, 0));
    View = glm::translate(View, -centreEsc);

    glUniformMatrix4fv (viewLoc, 1, GL_FALSE, &View[0][0]);
  }
  else
  {
    View = glm::lookAt(glm::vec3(15,3,12), glm::vec3(14,3,12), glm::vec3(0,1,0));

    glUniformMatrix4fv (viewLoc, 1, GL_FALSE, &View[0][0]);
  }
}

void MyGLWidget::projectTransform ()
{
  if (!camera2){
    glm::mat4 Proj;  // Matriu de projecció
    Proj = glm::perspective(fov, ra, zn, zf);

    glUniformMatrix4fv (projLoc, 1, GL_FALSE, &Proj[0][0]);
  }
  else
  {
    float fov2 = 90.0;
    float zn2 = 0.1;
    float zf2 = 15.0;
    glm::mat4 Proj;  // Matriu de projecció
    Proj = glm::perspective(fov2, ra, zn2, zf2);

    glUniformMatrix4fv (projLoc, 1, GL_FALSE, &Proj[0][0]);
  }
}


void MyGLWidget::CanviaCam(){
  makeCurrent();

    camera2 = !camera2;
    viewTransform();
    projectTransform();

  update();
}

void MyGLWidget::CanviaA(int n){
  makeCurrent();

    alçadaA = n;
    modelTransformAvio();

  update();
}

void MyGLWidget::moviment(){
  makeCurrent();

  angleA += float (2*M_PI/32.0);
  modelTransformAvio();

  update();
}

void MyGLWidget::keyPressEvent(QKeyEvent* event) 
{
  makeCurrent();
  switch (event->key()) {
  case Qt::Key_Up: {
      // ...
      if (alçadaA < 5) ++alçadaA;
      modelTransformAvio();
      emit Avio2(alçadaA);
    break;
	}
  case Qt::Key_Down: {
      // ...
      if (alçadaA > 0) --alçadaA;
      modelTransformAvio();
      emit Avio2(alçadaA);
    break;
	}
  case Qt::Key_Right: {
      // ...
      angleA += float (2*M_PI/32.0);
      modelTransformAvio();
    break;
	}
  case Qt::Key_F: {
      // ...
      focusC = !focusC;
      enviaPosFocus();
      iniMaterialTerra();
      ///iniCamera();
    break;
	}
  case Qt::Key_C: {
      // ...
      CanviaCam();
      emit cam2(camera2);
    break;
	}
  case Qt::Key_R: {
      // ...
      initializeGL();
    break;
	}
  case Qt::Key_S: {
      // ...
      if (timer.isActive()) timer.stop();
      else timer.start(100);
    break;
	}
  default: ExamGLWidget::keyPressEvent(event); break;
  }
  update();
}


void MyGLWidget::mouseMoveEvent(QMouseEvent *e)
{
  makeCurrent();
  if ((DoingInteractive == ROTATE) && !camera2)
  {
    // Fem la rotació
    angleY += (e->x() - xClick) * M_PI / ample;
    
  }
   // Fem la rotació
    angleX -= (e->y() - yClick) * M_PI / alt;
    viewTransform ();

  xClick = e->x();
  yClick = e->y();

  update ();
}

void MyGLWidget::carregaShaders() 
{
  // Creem els shaders per al fragment shader i el vertex shader
  QOpenGLShader fs (QOpenGLShader::Fragment, this);
  QOpenGLShader vs (QOpenGLShader::Vertex, this);
  // Carreguem el codi dels fitxers i els compilem
  fs.compileSourceFile("./shaders/basicLlumShader.frag");
  vs.compileSourceFile("./shaders/basicLlumShader.vert");
  // Creem el program
  program = new QOpenGLShaderProgram(this);
  // Li afegim els shaders corresponents
  program->addShader(&fs);
  program->addShader(&vs);
  // Linkem el program
  program->link();
  // Indiquem que aquest és el program que volem usar
  program->bind();

  // Obtenim identificador per a l'atribut “vertex” del vertex shader
  vertexLoc = glGetAttribLocation (program->programId(), "vertex");
  // Obtenim identificador per a l'atribut “normal” del vertex shader
  normalLoc = glGetAttribLocation (program->programId(), "normal");
  // Obtenim identificador per a l'atribut “matamb” del vertex shader
  matambLoc = glGetAttribLocation (program->programId(), "matamb");
  // Obtenim identificador per a l'atribut “matdiff” del vertex shader
  matdiffLoc = glGetAttribLocation (program->programId(), "matdiff");
  // Obtenim identificador per a l'atribut “matspec” del vertex shader
  matspecLoc = glGetAttribLocation (program->programId(), "matspec");
  // Obtenim identificador per a l'atribut “matshin” del vertex shader
  matshinLoc = glGetAttribLocation (program->programId(), "matshin");

  // Demanem identificadors per als uniforms dels shaders
  transLoc = glGetUniformLocation (program->programId(), "TG");
  projLoc = glGetUniformLocation (program->programId(), "proj");
  viewLoc = glGetUniformLocation (program->programId(), "view");
  posfocusLoc = glGetUniformLocation (program->programId(), "posFocus");
  posfocusLoc2 = glGetUniformLocation (program->programId(), "posFocus2");
}


