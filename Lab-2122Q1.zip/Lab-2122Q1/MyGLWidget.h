#include "ExamGLWidget.h"
#include <QTimer>

class MyGLWidget:public ExamGLWidget
{
  Q_OBJECT

  public:
    MyGLWidget(QWidget *parent=0) : ExamGLWidget(parent) {}
    ~MyGLWidget();

  protected:

  // initializeGL - Aqui incluim les inicialitzacions del contexte grafic.
    virtual void initializeGL ( );

    virtual void paintGL ();
    virtual void keyPressEvent(QKeyEvent* event);
    virtual void mouseMoveEvent (QMouseEvent *event);

    virtual void modelTransformPatricio ();
    virtual void modelTransformAvio ();
    virtual void iniEscena ();
    virtual void iniCamera ();
    virtual void projectTransform ();
    virtual void viewTransform ();
    virtual void enviaPosFocus ();
    virtual void iniMaterialTerra ();

    void carregaShaders ();
    //float angleX, angleY;

    

  private:
    int printOglError(const char file[], int line, const char func[]);
    bool focusC;
    float angleA; 
    int alçadaA;
    QTimer timer;
    GLuint posfocusLoc2;

  public slots:
    void CanviaCam();
    void CanviaA(int n);
    void moviment();

  signals:
    void cam2(bool);
    void Avio2(int n);



};
