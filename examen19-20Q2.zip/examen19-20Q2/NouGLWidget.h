#include "MyGLWidget.h"

class NouGLWidget : public MyGLWidget
{
 Q_OBJECT
	   
 public:
  NouGLWidget (QWidget *parent=NULL);
  ~NouGLWidget ();

 public slots:

 signals:

 protected:
  // initializeGL - Aqui incluim les inicialitzacions del contexte grafic.
  void initializeGL ();
  void paintGL ();
  void iniCamera ();
  void iniEscena ();
  void viewTransform ();
  void projectTransform ();
  void modelTransformPatricio2 (int escala, int npat);
  virtual void resizeGL (int width, int height);
  
  // keyPressEvent - Es cridat quan es prem una tecla
  void keyPressEvent (QKeyEvent *event);
  //float angleX, angleY;
  
 private:
    float passosX, passosZ, fov2, zn2, zf2;
    bool cam;

 public slots:
    void canviCam();

 signals:
    void cam2(bool);
    

};
