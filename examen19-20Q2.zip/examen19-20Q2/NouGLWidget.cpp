#include "NouGLWidget.h"

#include <iostream>

NouGLWidget::NouGLWidget(QWidget *parent) : MyGLWidget(parent) {
  grabKeyboard();
}

NouGLWidget::~NouGLWidget ()
{
}

void NouGLWidget::initializeGL ()
{
  // Cal inicialitzar l'ús de les funcions d'OpenGL
  MyGLWidget::initializeGL();
  passosX = 4.0;
  passosZ = 6.0;
  cam = false;
}
void NouGLWidget::paintGL() {
  // En cas de voler canviar els paràmetres del viewport, descomenteu la crida següent i
  // useu els paràmetres que considereu (els que hi ha són els de per defecte)
  //  glViewport (0, 0, ample, alt);
  
  // Esborrem el frame-buffer i el depth-buffer
  glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  //--------------------------------------------------------
  // Activem el VAO per a pintar el terra
  glBindVertexArray (VAO_Terra);  
  // pintem terra
  modelTransformTerra ();
  glDrawArrays(GL_TRIANGLES, 0, 12);

  //--------------------------------------------------------
  // Activem el VAO per a pintar el Patricio
  glBindVertexArray (VAO_Pat);
  // pintem el Patricio1
  modelTransformPatricio2(2,1);
  glDrawArrays(GL_TRIANGLES, 0, patModel.faces().size()*3);

  // pintem el Patricio2
  modelTransformPatricio2(3,2);
  glDrawArrays(GL_TRIANGLES, 0, patModel.faces().size()*3);


  //--------------------------------------------------------
  glBindVertexArray(0);
}

void NouGLWidget::iniCamera ()
{

  angleX = 0.0;
  angleY = float(M_PI/6.0);
  rav = 1.0;
  
  projectTransform ();
  viewTransform ();
  
}

void NouGLWidget::iniEscena ()
{
  //angleX = 0.0;
  //angleY = float(M_PI/6.0);

  MyGLWidget::iniEscena();
  centreEsc = glm::vec3 (4, 2, 4);
  radiEsc = 6; //arrel de 4 al quadrat + 4 al quadrat + 2 al quadrat

}

void NouGLWidget::modelTransformPatricio2 (int escala, int npat)
{
  // Codi per a la TG necessària
  glm::mat4 patTG = glm::mat4(1.0f);
  if (npat == 1){
    patTG = glm::translate(patTG, glm::vec3(2,0,1));
    patTG = glm::rotate(patTG, float(M_PI/2), glm::vec3(0,1,0));
  }
  else {
    patTG = glm::translate(patTG, glm::vec3(passosX,0,passosZ));
    patTG = glm::rotate(patTG, float(M_PI), glm::vec3(0,1,0));
  }
  patTG = glm::scale(patTG, glm::vec3(escalaPat*escala, escalaPat*escala, escalaPat*escala));
  patTG = glm::translate(patTG, -centreBasePat);
  glUniformMatrix4fv(transLoc, 1, GL_FALSE, &patTG[0][0]);
}

void NouGLWidget::viewTransform() {
  
  if (!cam){
    // Matriu de posició i orientació
  View = glm::translate(glm::mat4(1.f), glm::vec3(0, 0, -2*radiEsc));
  View = glm::rotate(View, angleX, glm::vec3(1, 0, 0));
  View = glm::rotate(View, -angleY, glm::vec3(0, 1, 0));
  View = glm::translate(View, -centreEsc);

  }
  else{
    View = glm::lookAt(glm::vec3(passosX,3.5,passosZ),glm::vec3(passosX,3.5,passosZ-1),glm::vec3(0,1,0));
  }

  glUniformMatrix4fv (viewLoc, 1, GL_FALSE, &View[0][0]);
}

void NouGLWidget::projectTransform() {
  float fov, zn, zf;
  glm::mat4 Proj;  // Matriu de projecció
  
  fov = float(M_PI/3.0);
  zn = radiEsc;
  zf = radiEsc*3;

  fov2 = float(M_PI/2.0);
  zn2 = 0.1;
  zf2 = 10;

  if (!cam)Proj = glm::perspective(fov, rav, zn, zf);
  else Proj = glm::perspective(fov2, rav, zn2, zf2);

  glUniformMatrix4fv (projLoc, 1, GL_FALSE, &Proj[0][0]);
}

void NouGLWidget::resizeGL (int w, int h)
{
  rav =  float(w) / float(h);
  if (rav > 1) fov2 = 2.0 * atan(tan(fov2/2.0));
  projectTransform ();
  glViewport(0,0,w,h);
}

void NouGLWidget::canviCam(){
  makeCurrent();
    cam = !cam;
    iniCamera();
  update();
}
void NouGLWidget::keyPressEvent(QKeyEvent* event)
{
  makeCurrent();
  switch (event->key()) {
    case Qt::Key_S: {

      if (passosZ < 8.0)passosZ += 0.5;
      viewTransform();
      break;
    }
    case Qt::Key_W: {

      if (passosZ > 0.0)passosZ -= 0.5;
      viewTransform();
      break;
    }
    case Qt::Key_A: {
      
      if (passosX > 0.0)passosX -= 0.5;
      viewTransform();
      break;
    }
    case Qt::Key_D: {
    
      if (passosX < 8.0)passosX += 0.5;
      viewTransform();
      break;
    }
    case Qt::Key_C: {
      
      cam = !cam;
      iniCamera();
      emit cam2(cam);
      break;
    }
    default: {
      MyGLWidget::keyPressEvent(event);
      break;
    }
  }
  update();
}

  
